fx_version "cerulean"
game "rdr3"
rdr3_warning "I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships."

files {
	"uiprompt.lua"
}

--[[
client_scripts {
	"uiprompt.lua",
	--"examples/single-prompt.lua",
	--"examples/multiple-controls.lua",
	--"examples/prompt-group.lua",
	--"examples/standard-mode.lua",
	--"examples/hold-mode.lua",
	--"examples/hold-mode-just-completed.lua",
	--"examples/custom-thread.lua",
	--"examples/cooldown.lua",
	--"examples/subclasses.lua",
	--"examples/test.lua",
}
]]
